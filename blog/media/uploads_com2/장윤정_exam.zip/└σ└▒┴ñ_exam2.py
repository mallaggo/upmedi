class Student:
    def __init__(self,name,kor,eng,math):
        self.name=name
        self.kor=kor
        self.eng=eng
        self.math=math

    def calc_avg(self):
        self.avg=round((self.kor+self.eng+self.math)/3,1)

    def display_info(self):
        print("=== 학생 성적 ===")
        print(f"이름: {self.name}")
        print(f"평균: {self.avg}")

    def save_to_file(self):
        with open("score.txt","w",encoding="utf-8") as f:
            f.write(f"{self.name},{self.avg}")

tname=input("이름을 입력하세요: ")
tkor=int(input("국어 점수를 입력하세요: "))
teng=int(input("영어 점수를 입력하세요: "))
tmath=int(input("수학 점수를 입력하세요: "))

e1=Student(tname, tkor, teng, tmath)
e1.calc_avg()
e1.display_info()
e1.save_to_file()
