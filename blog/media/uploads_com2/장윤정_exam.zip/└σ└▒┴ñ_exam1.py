import random

x=random.randint(1,100)

print("1부터 100 사이의 숫자를 맞춰보세요!")
cnt=0
while True:
    num = int(input("숫자를 입력하세요: "))

    cnt=cnt+1
    if x>num:
        print("더 큰 숫자입니다.")
    elif x<num:
        print("더 작은 숫자입니다.")
    else:
        print(f"정답입니다! {cnt}번 만에 맞췄어요.")
        break